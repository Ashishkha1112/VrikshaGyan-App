package np.edu.nast.vrikshagyanserver.entity;

public enum Role {
ADMIN,
USER,
VERIFIER
}
