package np.edu.nast.vrikshagyanserver.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import np.edu.nast.vrikshagyanserver.entity.plants.Plants;

public interface PlantRepository extends JpaRepository<Plants, Long> {
	
	Plants findByEnglishName(String englishName);

	boolean existsByEnglishName(String englishName);
	List<Plants> findByStatus(int i);
	List<Plants> findByStatusAndIsDeleted(int status, boolean isDeleted);
	List<Plants> findByisDeleted(boolean isDeleted);

	@Query("SELECT COUNT(p) FROM Plants p")
    long countTotalPlants();

    @Query("SELECT COUNT(p) FROM Plants p WHERE p.status = 1")
    long countVerifiedPlants();

    @Query("SELECT COUNT(p) FROM Plants p WHERE p.status = 0")
    long countUnverifiedPlants();

	
}
