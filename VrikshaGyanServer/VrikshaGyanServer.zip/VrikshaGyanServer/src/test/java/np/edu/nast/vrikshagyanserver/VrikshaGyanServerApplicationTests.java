package np.edu.nast.vrikshagyanserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VrikshaGyanServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
